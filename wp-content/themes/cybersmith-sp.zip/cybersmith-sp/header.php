<!DOCTYPE html>
<html>
 <head>
  <link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>" >
  <?php wp_head(); ?>
 </head>
 <body>
  <header>
   <?php include('php-child/VD_SP_header.php'); ?>
  </header>