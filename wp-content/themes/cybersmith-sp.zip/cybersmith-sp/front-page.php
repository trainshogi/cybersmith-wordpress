<?php get_header(); ?>

<?php include("php-child/VD_SP_toppage-02.php"); ?>
<?php include("php-child/VD_SP_toppage-03.php"); ?>
<?php include("php-child/VD_SP_toppage-04.php"); ?>
<?php include("php-child/VD_SP_toppage-05.php"); ?>
<?php include("php-child/VD_SP_toppage-06.php"); ?>
<?php include("php-child/VD_SP_toppage-07.php"); ?>
<?php include("php-child/VD_SP_toppage-08.php"); ?>

<?php get_footer(); ?>