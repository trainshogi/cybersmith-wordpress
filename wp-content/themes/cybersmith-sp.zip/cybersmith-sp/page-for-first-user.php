<?php get_header(); ?>

<?php include("php-child/VD_for_first_user-02.php"); ?>
<?php include('php-child/VD_for_first_user-03.php'); ?>
<?php include('php-child/VD_for_first_user-04.php'); ?>
<?php include('php-child/VD_for_first_user-05.php'); ?>
<?php include('php-child/VD_for_first_user-06.php'); ?>
<?php include('php-child/VD_for_first_user-07.php'); ?>

<?php get_footer(); ?>