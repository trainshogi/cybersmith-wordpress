<svg id="bd2e71e2-61c4-4c10-84db-758f3d8234d0" data-name="レイヤー 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 374 84">
  <defs>
    <style>
      .b274c134-3047-4f0c-a851-81fa0f9f45a7 {
        font-size: 14px;
        font-family: HiraKakuProN-W6-83pv-RKSJ-H, Hiragino Kaku Gothic ProN;
        letter-spacing: 0.1em;
      }
    </style>
  </defs>
  <a href="/"><text class="b274c134-3047-4f0c-a851-81fa0f9f45a7" transform="translate(27.27 64.46)">トップページ</text></a>
</svg>
