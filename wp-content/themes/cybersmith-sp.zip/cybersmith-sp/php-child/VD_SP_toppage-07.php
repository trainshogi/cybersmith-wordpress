<svg id="b2ccaac3-bc05-4695-9c2e-0a1e756eaa90" data-name="レイヤー 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 374 569">
  <defs>
    <style>
      .fb082c37-e633-4f7c-9068-43dc88dddbdc {
        font-size: 24px;
        font-family: AGaramondPro-Regular, Adobe Garamond Pro;
      }

      .a14c73bd-86dd-4267-9ade-5db2d20a61c5, .fb082c37-e633-4f7c-9068-43dc88dddbdc {
        letter-spacing: 0.2em;
      }

      .a14c73bd-86dd-4267-9ade-5db2d20a61c5, .f30135f6-9a95-4d5b-a149-299adc9b104f {
        font-size: 12px;
      }

      .a14c73bd-86dd-4267-9ade-5db2d20a61c5 {
        font-family: DNPShueiMGoStd-B-83pv-RKSJ-H, DNP ShueiMGoStd;
      }

      .f30135f6-9a95-4d5b-a149-299adc9b104f {
        font-family: HiraKakuProN-W3-83pv-RKSJ-H, Hiragino Kaku Gothic ProN;
        letter-spacing: 0.1em;
      }

      .b9bb8dec-5586-4a51-bff7-742438169577 {
        font-size: 14px;
        font-family: HiraginoSans-W6-83pv-RKSJ-H, Hiragino Sans;
        letter-spacing: 0.3em;
      }

      .bf538556-6134-434f-99c4-79792ded1bad {
        fill: #fff;
      }

      .b4873f2b-449d-43a5-b31b-b5f577955f06 {
        fill: none;
        stroke: #000;
        stroke-miterlimit: 10;
      }
    </style>
  </defs>
  <text class="fb082c37-e633-4f7c-9068-43dc88dddbdc" transform="translate(73.57 72.75)">INFORMATION</text>
  <text class="a14c73bd-86dd-4267-9ade-5db2d20a61c5" transform="translate(35 139.64)">2019.12.31</text>
  <text class="f30135f6-9a95-4d5b-a149-299adc9b104f" transform="translate(34 160.64)">サンプルサンプルサンプルサンプルサンプルサンプル<tspan x="0" y="21">サンプルサンプルサンプルサンプルル</tspan></text>
  <text class="a14c73bd-86dd-4267-9ade-5db2d20a61c5" transform="translate(35 211.64)">2019.12.31</text>
  <text class="f30135f6-9a95-4d5b-a149-299adc9b104f" transform="translate(34 232.64)">サンプルサンプルサンプルサンプルサンプルサンプル<tspan x="0" y="21">サンプルサンプルサンプルサンプルル</tspan></text>
  <text class="a14c73bd-86dd-4267-9ade-5db2d20a61c5" transform="translate(35 283.64)">2019.12.31</text>
  <text class="f30135f6-9a95-4d5b-a149-299adc9b104f" transform="translate(34 304.64)">サンプルサンプルサンプルサンプルサンプルサンプル<tspan x="0" y="21">サンプルサンプルサンプルサンプルル</tspan></text>
  <text class="a14c73bd-86dd-4267-9ade-5db2d20a61c5" transform="translate(35 355.64)">2019.12.31</text>
  <text class="f30135f6-9a95-4d5b-a149-299adc9b104f" transform="translate(34 376.64)">サンプルサンプルサンプルサンプルサンプルサンプル<tspan x="0" y="21">サンプルサンプルサンプルサンプルル</tspan></text>
  <text class="a14c73bd-86dd-4267-9ade-5db2d20a61c5" transform="translate(35 427.64)">2019.12.31</text>
  <text class="f30135f6-9a95-4d5b-a149-299adc9b104f" transform="translate(34 448.64)">サンプルサンプルサンプルサンプルサンプルサンプル<tspan x="0" y="21">サンプルサンプルサンプルサンプルル</tspan></text>
  <text class="b9bb8dec-5586-4a51-bff7-742438169577" transform="translate(76.51 520.97)">VIEW MORE</text>
  <g>
    <circle cx="48.23" cy="516.16" r="13.51"/>
    <g>
      <path class="bf538556-6134-434f-99c4-79792ded1bad" d="M49.49,516.38s0,0,0,0h0a.14.14,0,0,0,0-.06v0a.38.38,0,0,0,0-.15h0a.14.14,0,0,0,0-.06v0l0,0-.05-.06L44,510.47a.39.39,0,0,0-.55,0l-1,1a.36.36,0,0,0-.12.27.39.39,0,0,0,.12.28l4.11,4.11-4.11,4.11a.36.36,0,0,0-.12.27.38.38,0,0,0,.12.28l1,1a.38.38,0,0,0,.27.11.38.38,0,0,0,.28-.11l5.42-5.42Z"/>
      <path class="bf538556-6134-434f-99c4-79792ded1bad" d="M55.49,516.33h0a.14.14,0,0,0,0-.06v0a.38.38,0,0,0,0-.15h0a.14.14,0,0,0,0-.06v0l0,0-.05-.06L50,510.47a.39.39,0,0,0-.55,0l-1,1a.39.39,0,0,0-.11.27.43.43,0,0,0,.11.28l4.11,4.11-4.11,4.11a.39.39,0,0,0-.11.27.41.41,0,0,0,.11.28l1,1a.38.38,0,0,0,.28.11.35.35,0,0,0,.27-.11l5.42-5.42.05-.06Z"/>
    </g>
  </g>
  <line class="b4873f2b-449d-43a5-b31b-b5f577955f06" x1="75.7" y1="528.45" x2="199.2" y2="528.45"/>
</svg>
