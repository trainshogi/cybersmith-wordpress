<svg id="a33d87b3-d922-4b30-b0b9-7ada070e03c6" data-name="レイヤー 1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 375 602">
  <defs>
    <style>
      .e1d601b7-278e-471f-ba7c-be33135cd54f {
        fill: #fff;
      }

      .e609615f-fee3-4f59-a009-d10c38ecd55d {
        font-size: 32px;
        font-family: FutoGoB101Pr6N-Bold, FutoGoB101Pr6N Bold-83pv-RKSJ-H;
        font-weight: 700;
        letter-spacing: 0.2em;
      }

      .be5c0efd-2c05-45e4-ac39-44f459f8a3c0 {
        font-size: 16px;
        font-family: HiraKakuProN-W3-83pv-RKSJ-H, Hiragino Kaku Gothic ProN;
        letter-spacing: 0.1em;
      }

      .eb60c44b-ecc7-4256-bace-e523c9bdf79e {
        letter-spacing: -0.4em;
      }

      .aa69de43-8bb8-4329-859a-a1205a3b1732 {
        opacity: 0.3;
      }

      .f1568b55-2e44-4a26-81a1-e98e3b0aeedf {
        fill: #dc4335;
      }

      .b5b3903e-1467-4b3d-84a3-6b46b1dffcdf {
        fill: none;
        stroke: #000;
        stroke-miterlimit: 10;
      }

      .f4a93538-850d-49d1-a80d-dc89a88c97b8 {
        font-size: 18px;
        font-family: KozGoPr6N-Bold-83pv-RKSJ-H, Kozuka Gothic Pr6N;
      }
    </style>
  </defs>
  <image width="1980" height="1413" transform="translate(-310.98 -34.02) scale(0.45)" xlink:href="http://3.112.250.183/wp-content/uploads/2021/12/earth.png"/>
  <rect class="e1d601b7-278e-471f-ba7c-be33135cd54f" x="22" y="164" width="296" height="60"/>
  <rect class="e1d601b7-278e-471f-ba7c-be33135cd54f" x="22" y="230" width="212" height="43"/>
  <rect class="e1d601b7-278e-471f-ba7c-be33135cd54f" x="22" y="344" width="337" height="211"/>
  <text class="e609615f-fee3-4f59-a009-d10c38ecd55d" transform="translate(39.62 207.05)">幸福が循環する<tspan x="0" y="56">社会を創る</tspan></text>
  <text class="be5c0efd-2c05-45e4-ac39-44f459f8a3c0" transform="translate(46.41 386.88)">世の中を良くするために、テクノロ<tspan x="0" y="28">ジーを活用し</tspan><tspan class="eb60c44b-ecc7-4256-bace-e523c9bdf79e" x="105.6" y="28">、</tspan><tspan x="0" y="56">世の中のあらゆる課題を解決するた</tspan><tspan x="0" y="84">めのサービスをつくる</tspan><tspan class="eb60c44b-ecc7-4256-bace-e523c9bdf79e" x="176" y="84">、</tspan><tspan x="0" y="112">プロフェッショナル人材同士が豊か</tspan><tspan x="0" y="140">につながる幸福の輪</tspan><tspan class="eb60c44b-ecc7-4256-bace-e523c9bdf79e" x="158.4" y="140">。</tspan></text>
</svg>
