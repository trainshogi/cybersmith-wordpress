<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 375 787">
  <defs>
    <style>
      .a7985706-caa3-49bc-873b-b4751d68c154 {
        isolation: isolate;
      }

      .a818cbaa-0169-4703-b220-2f53a32adfa2 {
        font-size: 32px;
        font-family: A1MinchoStd-Bold-83pv-RKSJ-H, A-OTF A1 Mincho Std;
        letter-spacing: 0.2em;
      }

      .bb210fd5-1f57-470e-9271-51e46a0dfb15 {
        font-size: 18px;
        font-family: HiraKakuProN-W3-83pv-RKSJ-H, Hiragino Kaku Gothic ProN;
        letter-spacing: 0.1em;
      }

      .bf7edfee-4b74-403e-ae20-2a21ffa57283 {
        letter-spacing: -0.4em;
      }

      .ae09f5ef-5f38-4dc5-b765-d77505ff1f80 {
        letter-spacing: -0.4em;
      }

      .b3f05cc9-ad97-492f-bd9a-2b6fd27784bf, .f19a9117-b37f-45cf-adaa-41dc36b99e4b {
        font-size: 14px;
        letter-spacing: 0.3em;
      }

      .ea3c7649-c1e1-4671-a4cc-98794f18e93a-2 {
        stroke: #dc4335;
      }

      .ea3c7649-c1e1-4671-a4cc-98794f18e93a {
        fill: #dc4335;
      }

      .b3f05cc9-ad97-492f-bd9a-2b6fd27784bf {
        font-family: HiraginoSans-W6-83pv-RKSJ-H, Hiragino Sans;
      }

      .badf094b-ed70-4bcd-b3be-5e5bdcc9d2b2 {
        fill: #fff;
      }

      .bbd32dfe-c62a-4083-92f8-80991de3f299 {
        fill: none;
        stroke: #dc4335;
        stroke-miterlimit: 10;
      }

      .bc8d11e7-bc76-4fcc-b77f-5d9535c0d1d9 {
        opacity: 0.16;
      }

      .abdd784f-a9e8-4756-bbe0-084732175a74 {
        fill: #ac263d;
      }

      .bb5ba4af-4ae4-4a82-a113-99dc01547981 {
        fill: #4cb3d3;
      }

      .a91b2488-2d55-47c1-ae3e-ada094508879 {
        fill: #4aa3c1;
      }

      .f9ac6bb1-7842-4957-9ab4-1727c7a57362 {
        fill: #1178b7;
      }

      .bfd3630a-2f7e-4a4a-8bc5-bf073f39eddf {
        fill: #1883c6;
      }

      .b852029a-a2ea-44a6-beb8-864fd5f05105 {
        mix-blend-mode: multiply;
      }

      .acd09019-e7fa-4211-ba58-0237550e2574 {
        fill: #311e69;
      }

      .a71fc60a-a25a-45aa-ac2a-2c9aaba438ca {
        fill: #1e1240;
      }

      .fe860488-c800-4f9c-9722-2186d4a5a985 {
        fill: #fc9b7a;
      }

      .aafb04d1-2f85-423f-870c-5a35c0a6a07b {
        fill: #ffa986;
      }

      .a3e66042-fc46-4660-9bc7-e7f0844d4de2 {
        fill: #ad263d;
      }

      .f5668431-b976-4184-96f2-d47a60c4071a {
        fill: #f96291;
      }

      .b9d27438-80c8-4f60-b0f1-19409d330d2e {
        fill: #614cd4;
      }

      .f9255890-1ffc-4129-83a6-c88facb6e218 {
        fill: #d95f76;
      }

      .a41ee5e9-8677-4add-aa77-8416c01f4f68 {
        fill: #aa3766;
      }

      .a46e4c25-91e6-45aa-ac2c-75a7699dc5cd {
        fill: #ff8da8;
      }

      .bb7f5eb7-a9eb-423c-8173-aef7804b5556 {
        fill: #473399;
      }

      .b0c66e56-5ef1-45ed-8202-3ff30ca0d31d {
        fill: #9388ff;
      }

      .a8b8065c-d68e-4968-9c15-14076099a048 {
        fill: #6d55ed;
      }

      .b306083f-0c49-4018-881d-13bcd5f6290a {
        fill: #f1f1f1;
      }

      .a8331849-3a2c-46d3-b7bd-b7898e3c7345 {
        fill: #ffc4c4;
      }

      .e331d68c-aae4-484e-b351-dc17821ba696 {
        fill: #bcd560;
      }
    </style>
  </defs>
  <g class="a7985706-caa3-49bc-873b-b4751d68c154">
    <g id="b29fcbd7-7568-455f-83a5-1eeb68779f7a" data-name="レイヤー 1">
      <text class="a818cbaa-0169-4703-b220-2f53a32adfa2" transform="translate(30.88 117.81)">サイバースミスに<tspan x="0" y="52">できること</tspan></text>
      <text class="bb210fd5-1f57-470e-9271-51e46a0dfb15" transform="translate(39.12 228.89)">人と人をつなげ<tspan class="bf7edfee-4b74-403e-ae20-2a21ffa57283" x="138.6" y="0">、</tspan><tspan x="0" y="31.5">あらゆる課題を解決し</tspan><tspan class="bf7edfee-4b74-403e-ae20-2a21ffa57283" x="198" y="31.5">、</tspan><tspan x="0" y="63">世の中を良くするために</tspan><tspan x="0" y="94.5">活動していきます</tspan><tspan class="ae09f5ef-5f38-4dc5-b765-d77505ff1f80" x="158.4" y="94.5">。</tspan></text>
      <text class="f19a9117-b37f-45cf-adaa-41dc36b99e4b" transform="translate(57.15 58.09)">CYBER SMITH</text>
      <line class="ea3c7649-c1e1-4671-a4cc-98794f18e93a-2" x1="50.93" y1="41.6" x2="34.93" y2="57.6"/>
      <g><a href="../company_sp/">
        <text class="b3f05cc9-ad97-492f-bd9a-2b6fd27784bf" transform="translate(85.25 395.5)">VIEW MORE</text>
        <line class="bbd32dfe-c62a-4083-92f8-80991de3f299" x1="85.93" y1="401.1" x2="207.93" y2="401.1"/>
        <circle class="ea3c7649-c1e1-4671-a4cc-98794f18e93a" cx="58.51" cy="389.71" r="13.51"/>
        <g>
          <path class="badf094b-ed70-4bcd-b3be-5e5bdcc9d2b2" d="M59.77,389.93s0,0,0-.05v0a.14.14,0,0,0,0-.06h0a.38.38,0,0,0,0-.15h0a.14.14,0,0,0,0-.06v0l0-.05-.05-.06L54.3,384a.39.39,0,0,0-.55,0l-1,1a.44.44,0,0,0-.12.28.4.4,0,0,0,.12.27l4.11,4.11-4.11,4.11a.39.39,0,0,0,0,.56l1,1a.43.43,0,0,0,.28.11.39.39,0,0,0,.27-.11L59.72,390Z"/>
          <path class="badf094b-ed70-4bcd-b3be-5e5bdcc9d2b2" d="M65.77,389.88v0s0,0,0-.06h0a.38.38,0,0,0,0-.15h0s0,0,0-.06v0l0-.05,0-.06L60.27,384a.39.39,0,0,0-.55,0l-1,1a.43.43,0,0,0-.11.28.39.39,0,0,0,.11.27l4.11,4.11-4.11,4.11a.41.41,0,0,0,0,.56l1,1a.43.43,0,0,0,.28.11.39.39,0,0,0,.27-.11L65.69,390l0-.06Z"/>
        </g>
      </a></g>
      <image href="http://3.112.250.183/wp-content/uploads/2021/12/earth_with_people.gif" x="31.14" y="440.28" height="278.3" width="303.78"/>
    </g>
  </g>
</svg>
