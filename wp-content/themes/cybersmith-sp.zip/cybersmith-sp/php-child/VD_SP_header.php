<svg id="header_sp" data-name="レイヤー 1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 375 101">
  <defs>
    <style>
      .af4729ae-68bc-4bd3-aa67-0daac68d96e5 {
        fill: #fff;
      }

      .b33b5fa0-8b35-49b8-b58f-dff3bffad9d0 {
        opacity: 0.3;
      }

      .fa5f6573-47fd-4cef-b12a-cd2d85a80557 {
        fill: #db4335;
      }

      .a3704b65-0ca9-47af-b181-be632d0f6ea8 {
        fill: none;
        stroke: #000;
        stroke-miterlimit: 10;
      }

      .f4fba615-e3ea-4354-8873-c7974fee194f {
        font-size: 18px;
        font-family: KozGoPr6N-Bold-83pv-RKSJ-H, Kozuka Gothic Pr6N;
      }
    </style>
  </defs>
  <rect class="af4729ae-68bc-4bd3-aa67-0daac68d96e5" x="20.95" y="21.91" width="337" height="75" rx="10"/>
  <g class="b33b5fa0-8b35-49b8-b58f-dff3bffad9d0">
    <path class="fa5f6573-47fd-4cef-b12a-cd2d85a80557" d="M348,21.91a10,10,0,0,1,10,10v55a10,10,0,0,1-10,10H31a10,10,0,0,1-10-10v-55a10,10,0,0,1,10-10H348m0-5H31a15,15,0,0,0-15,15v55a15,15,0,0,0,15,15H348a15,15,0,0,0,15-15v-55a15,15,0,0,0-15-15Z"/>
  </g>
  <g id="humberger_open">
    <line class="a3704b65-0ca9-47af-b181-be632d0f6ea8" x1="51.95" y1="53.91" x2="89.95" y2="53.91"/>
    <line class="a3704b65-0ca9-47af-b181-be632d0f6ea8" x1="51.95" y1="62.41" x2="89.95" y2="62.41"/>
    <line class="a3704b65-0ca9-47af-b181-be632d0f6ea8" x1="51.95" y1="71.41" x2="89.95" y2="71.41"/>
  </g>
  <text class="f4fba615-e3ea-4354-8873-c7974fee194f" transform="translate(162.57 69.93)">サイバースミス</text>
  <image width="2460" height="562" transform="translate(134 39) scale(0.07 0.08)" xlink:href="http://3.112.250.183/wp-content/uploads/2021/11/cybersmith-logo.png"/>
</svg>