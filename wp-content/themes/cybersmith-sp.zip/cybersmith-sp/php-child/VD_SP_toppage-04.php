<div class="wrap_svgbg" style="position: relative; width:100vw; height:408vw;">
  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 375 1532" style="position: absolute; width:100vw; height:408vw;">
    <defs>
      <style>
        .b16420e0-8b1e-444f-92b5-6e6ce56a7b60 {
          isolation: isolate;
        }

        .a13cb2ce-eea7-44ae-9950-fa14f9208eb6, .ba131054-94e3-4bf3-bcf7-5d76bade886b, .ba3b6020-1767-4440-bec4-33252456bc31 {
          fill: #83ccd2;
        }

        .a13cb2ce-eea7-44ae-9950-fa14f9208eb6, .bc4267ef-c781-4c82-b39d-761d107383ae {
          opacity: 0.15;
        }

        .eef0a675-490a-444d-a166-8853a300c048 {
          opacity: 0.16;
        }

        .a6fb728e-886b-4199-aa38-1911aed5cc30, .afd05b80-a7d8-4735-8047-9b775c17b657 {
          fill: none;
          stroke: #000;
        }

        .afd05b80-a7d8-4735-8047-9b775c17b657 {
          stroke-linecap: round;
          stroke-linejoin: round;
          stroke-width: 1.69px;
        }

        .a472110a-fd09-4fe3-b8f9-c387215f19e5 {
          fill: #949494;
        }

        .f72dac7f-b23b-403c-a82b-2bf8a883154e {
          fill: #a7a7a7;
        }

        .a7847a72-cb95-4a51-9895-82502a883b42 {
          fill: #868686;
        }

        .b36aa45f-bc48-445b-864b-e8eb4239f598 {
          fill: #bdbdbd;
        }

        .b91c8b58-5547-4fb6-8314-fc5566156702 {
          font-size: 16px;
          letter-spacing: 0.1em;
        }

        .b91c8b58-5547-4fb6-8314-fc5566156702, .bca0c4f6-af30-43ea-9887-137b386d9f2d, .bef307e8-9643-4cbe-b5be-8de0645089b9 {
          font-family: HiraKakuProN-W3-83pv-RKSJ-H, Hiragino Kaku Gothic ProN;
        }

        .efb6ba7b-2cfa-4542-b530-5a7c4e0eda71 {
          letter-spacing: -0.4em;
        }

        .ff24884f-28b2-4729-9ebf-4dda5a1a114d {
          letter-spacing: -0.4em;
        }

        .b624284c-5327-46fb-9842-bc9e36c505a7 {
          letter-spacing: 0.35em;
        }

        .ba131054-94e3-4bf3-bcf7-5d76bade886b {
          font-size: 24px;
          letter-spacing: 0.1em;
        }

        .ac31d36e-ca8d-419c-b7cb-23e22432e3ae {
          font-size: 26px;
          font-family: FutoGoB101Pr6N-Bold, FutoGoB101Pr6N Bold-83pv-RKSJ-H;
          font-weight: 700;
          letter-spacing: 0.2em;
        }

        .a4994349-7b19-434e-be19-b033bbb12065 {
          font-size: 14px;
          letter-spacing: 0.3em;
        }

        .a4994349-7b19-434e-be19-b033bbb12065, .b54807a0-ed97-4ce5-8da1-530392ed9a4b {
          font-family: HiraginoSans-W6-83pv-RKSJ-H, Hiragino Sans;
        }

        .f1197513-0e57-47da-a99d-f29b45d8386e {
          fill: #fff;
        }

        .a6fb728e-886b-4199-aa38-1911aed5cc30 {
          stroke-miterlimit: 10;
        }

        .a48ae372-5c41-4ef9-b888-6d98aabae86f {
          mix-blend-mode: multiply;
          opacity: 0.45;
        }

        .bef307e8-9643-4cbe-b5be-8de0645089b9 {
          font-size: 18px;
          letter-spacing: 0.1em;
        }

        .b8c5905a-583d-46ec-864a-71afb9809446 {
          letter-spacing: 0.35em;
        }

        .b54807a0-ed97-4ce5-8da1-530392ed9a4b, .bca0c4f6-af30-43ea-9887-137b386d9f2d {
          font-size: 12px;
        }

        .bca0c4f6-af30-43ea-9887-137b386d9f2d {
          fill: #333;
          letter-spacing: 0.1em;
        }

        .b5974ad8-23a4-4668-a4fb-401488fdd84b {
          letter-spacing: 0.35em;
        }

        .b0f6fbe1-a9b6-4026-b941-c3d330219a47 {
          letter-spacing: -0.15em;
        }

        .a325178f-77a1-4c0d-ae65-ca65b9b21fd7 {
          letter-spacing: -0.15em;
        }

        .ac2bb35a-07bd-4c58-a2b8-a99bd33783da {
          letter-spacing: 0.1em;
        }

        .b54807a0-ed97-4ce5-8da1-530392ed9a4b {
          letter-spacing: 0.3em;
        }

        .ba9d83f9-a7f1-41c4-95c9-4067b7779854 {
          letter-spacing: -0.4em;
        }

        .bc4267ef-c781-4c82-b39d-761d107383ae {
          fill: #4aa643;
        }
      </style>
    </defs>
    <g class="b16420e0-8b1e-444f-92b5-6e6ce56a7b60">
      <g id="aba8e34f-05d2-4491-8840-9b9f2e41fc49" data-name="レイヤー 1">
        <rect class="a13cb2ce-eea7-44ae-9950-fa14f9208eb6" x="-14.01" y="0.11" width="405.01" height="1530.89"/>
        <g class="eef0a675-490a-444d-a166-8853a300c048">
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="461.89 414.25 394.36 336.82 365.66 494.37 461.89 414.25"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="290.73 461.85 394.36 336.82 365.66 494.37 290.73 461.85"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="180.31 496.57 186.44 614.14 365.66 494.37 180.31 496.57"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="180.31 496.57 186.44 614.14 93.87 359.73 180.31 496.57"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="-1.47 480.94 186.44 614.14 93.87 359.73 -1.47 480.94"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="-1.47 480.94 186.44 614.14 -35.63 830.29 -1.47 480.94"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="104.72 874.99 186.44 614.14 -35.63 830.29 104.72 874.99"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="290.73 461.85 180.31 496.57 365.66 494.37 290.73 461.85"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="290.73 461.85 180.31 496.57 93.87 359.73 290.73 461.85"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="583.31 754.55 369.54 646.35 524.59 684.27 583.31 754.55"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="369.54 646.35 583.31 754.55 466.71 733.49 369.54 646.35"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="551.57 593.81 369.54 646.35 524.59 684.27 551.57 593.81"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="369.54 646.35 551.57 593.81 269.06 631.3 369.54 646.35"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="369.54 646.35 262.65 772.57 269.06 631.3 369.54 646.35"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="186.44 614.14 262.65 772.57 269.06 631.3 186.44 614.14"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="186.44 614.14 365.66 494.37 269.06 631.3 186.44 614.14"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="369.54 646.35 262.65 772.57 354.18 788.16 369.54 646.35"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="320.47 921.53 262.65 772.57 354.18 788.16 320.47 921.53"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="551.57 593.81 365.66 494.37 508.69 484.5 551.57 593.81"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="365.66 494.37 551.57 593.81 269.06 631.3 365.66 494.37"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="461.89 414.25 365.66 494.37 508.69 484.5 461.89 414.25"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="328.19 1033.19 619.13 1147.58 437.38 1121.59 328.19 1033.19"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="619.13 1147.58 328.19 1033.19 456.59 1005.83 619.13 1147.58"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="328.19 1033.19 473.39 860.12 320.47 921.53 328.19 1033.19"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="328.19 1033.19 205.41 844.03 320.47 921.53 328.19 1033.19"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="328.19 1033.19 205.41 844.03 227.34 1094.71 328.19 1033.19"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="104.72 874.99 205.41 844.03 227.34 1094.71 104.72 874.99"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="104.72 874.99 205.41 844.03 186.44 614.14 104.72 874.99"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="104.72 874.99 72.31 1077.5 227.34 1094.71 104.72 874.99"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="104.72 874.99 72.31 1077.5 -35.63 830.29 104.72 874.99"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="328.19 1033.19 302.25 1219.61 227.34 1094.71 328.19 1033.19"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="328.19 1033.19 302.25 1219.61 437.38 1121.59 328.19 1033.19"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="455.14 1282.35 302.25 1219.61 437.38 1121.59 455.14 1282.35"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="455.14 1282.35 302.25 1219.61 537.04 1460.99 455.14 1282.35"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="312.52 1424.01 302.25 1219.61 537.04 1460.99 312.52 1424.01"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="312.52 1424.01 302.25 1219.61 182.3 1163.74 312.52 1424.01"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="312.52 1424.01 227.96 1431.31 182.3 1163.74 312.52 1424.01"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="23.75 1337.04 227.96 1431.31 182.3 1163.74 23.75 1337.04"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="23.75 1337.04 -1.76 1178.47 182.3 1163.74 23.75 1337.04"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="72.31 1077.5 -1.76 1178.47 182.3 1163.74 72.31 1077.5"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="227.34 1094.71 302.25 1219.61 182.3 1163.74 227.34 1094.71"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="227.34 1094.71 72.31 1077.5 182.3 1163.74 227.34 1094.71"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="262.65 772.57 205.41 844.03 320.47 921.53 262.65 772.57"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="262.65 772.57 205.41 844.03 186.44 614.14 262.65 772.57"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="473.39 860.12 328.19 1033.19 456.59 1005.83 473.39 860.12"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="354.18 788.16 473.39 860.12 320.47 921.53 354.18 788.16"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="473.39 860.12 354.18 788.16 466.71 733.49 473.39 860.12"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="369.54 646.36 354.18 788.16 466.71 733.49 369.54 646.36"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="290.73 461.85 394.36 336.82 389.43 546.73 290.73 461.85"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="180.31 496.57 103.23 621.8 389.43 546.73 180.31 496.57"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="180.31 496.57 103.23 621.8 93.87 359.73 180.31 496.57"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="-1.47 480.94 103.23 621.8 93.87 359.73 -1.47 480.94"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="-1.47 480.94 103.23 621.8 -1.49 728.51 -1.47 480.94"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="104.72 874.99 103.23 621.8 -1.49 728.51 104.72 874.99"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="104.72 874.99 -28.66 884.78 -1.49 728.51 104.72 874.99"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="290.73 461.85 180.31 496.57 389.43 546.73 290.73 461.85"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="290.73 461.85 180.31 496.57 93.87 359.73 290.73 461.85"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="583.31 754.55 369.54 646.35 531.38 647.66 583.31 754.55"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="369.54 646.35 583.31 754.55 466.71 733.49 369.54 646.35"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="551.57 593.81 369.54 646.35 531.38 647.66 551.57 593.81"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="369.54 646.35 551.57 593.81 269.06 631.3 369.54 646.35"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="369.54 646.35 262.65 772.57 269.06 631.3 369.54 646.35"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="103.23 621.8 262.65 772.57 269.06 631.3 103.23 621.8"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="103.23 621.8 389.43 546.73 269.06 631.3 103.23 621.8"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="369.54 646.35 262.65 772.57 354.18 788.16 369.54 646.35"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="406.78 873.99 262.65 772.57 354.18 788.16 406.78 873.99"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="389.43 546.73 551.57 593.81 269.06 631.3 389.43 546.73"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="373.67 1017.68 619.13 1147.58 437.38 1121.59 373.67 1017.68"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="619.13 1147.58 373.67 1017.68 456.59 1005.83 619.13 1147.58"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="373.67 1017.68 473.39 860.12 406.78 873.99 373.67 1017.68"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="373.67 1017.68 205.41 844.03 406.78 873.99 373.67 1017.68"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="373.67 1017.68 205.41 844.03 239.99 980.22 373.67 1017.68"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="104.72 874.99 205.41 844.03 239.99 980.22 104.72 874.99"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="104.72 874.99 205.41 844.03 103.23 621.8 104.72 874.99"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="104.72 874.99 119.12 1052.81 239.99 980.22 104.72 874.99"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="104.72 874.99 119.12 1052.81 19.46 1008.63 104.72 874.99"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="42.02 1142.21 119.12 1052.81 19.46 1008.63 42.02 1142.21"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="42.02 1142.21 119.12 1052.81 182.3 1163.74 42.02 1142.21"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="42.02 1142.21 124.45 1338.42 182.3 1163.74 42.02 1142.21"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="227.96 1431.31 124.45 1338.42 182.3 1163.74 227.96 1431.31"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="227.96 1431.31 124.45 1338.42 113.68 1449.33 227.96 1431.31"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="373.67 1017.68 302.25 1219.61 239.99 980.22 373.67 1017.68"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="373.67 1017.68 302.25 1219.61 437.38 1121.59 373.67 1017.68"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="534.78 1240.81 302.25 1219.61 437.38 1121.59 534.78 1240.81"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="534.78 1240.81 302.25 1219.61 490.92 1392.58 534.78 1240.81"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="347.21 1372.37 302.25 1219.61 490.92 1392.58 347.21 1372.37"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="347.21 1372.37 302.25 1219.61 182.3 1163.74 347.21 1372.37"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="347.21 1372.37 227.96 1431.31 182.3 1163.74 347.21 1372.37"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="239.99 980.22 302.25 1219.61 182.3 1163.74 239.99 980.22"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="239.99 980.22 119.12 1052.81 182.3 1163.74 239.99 980.22"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="262.65 772.57 205.41 844.03 406.78 873.99 262.65 772.57"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="262.65 772.57 205.41 844.03 103.23 621.8 262.65 772.57"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="473.39 860.12 373.67 1017.68 456.59 1005.83 473.39 860.12"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="354.18 788.16 473.39 860.12 406.78 873.99 354.18 788.16"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="473.39 860.12 354.18 788.16 466.71 733.49 473.39 860.12"/>
          <polygon class="afd05b80-a7d8-4735-8047-9b775c17b657" points="369.54 646.36 354.18 788.16 466.71 733.49 369.54 646.36"/>
          <path d="M232.2,953.74A27.61,27.61,0,1,1,213.51,988,27.6,27.6,0,0,1,232.2,953.74Z"/>
          <path class="a472110a-fd09-4fe3-b8f9-c387215f19e5" d="M348.58,769.14a19.83,19.83,0,1,1-13.42,24.61A19.82,19.82,0,0,1,348.58,769.14Z"/>
          <path class="f72dac7f-b23b-403c-a82b-2bf8a883154e" d="M297.41,1203.16a17.14,17.14,0,1,1-11.61,21.28A17.15,17.15,0,0,1,297.41,1203.16Z"/>
          <path class="a7847a72-cb95-4a51-9895-82502a883b42" d="M114.28,1036.36a17.15,17.15,0,1,1-11.61,21.29A17.15,17.15,0,0,1,114.28,1036.36Z"/>
          <path class="b36aa45f-bc48-445b-864b-e8eb4239f598" d="M223.12,1414.86a17.15,17.15,0,1,1-11.6,21.28A17.15,17.15,0,0,1,223.12,1414.86Z"/>
          <path class="a7847a72-cb95-4a51-9895-82502a883b42" d="M382.37,522.74a25,25,0,1,1-16.93,31A25,25,0,0,1,382.37,522.74Z"/>
          <path class="b36aa45f-bc48-445b-864b-e8eb4239f598" d="M96.17,597.81a25,25,0,1,1-16.93,31.05A25,25,0,0,1,96.17,597.81Z"/>
          <path d="M343.68,1360.37a12.5,12.5,0,1,1-8.46,15.53A12.5,12.5,0,0,1,343.68,1360.37Z"/>
          <path d="M90.34,347.73a12.5,12.5,0,1,1-8.47,15.53A12.49,12.49,0,0,1,90.34,347.73Z"/>
          <path d="M259.12,760.58a12.5,12.5,0,1,1-8.46,15.52A12.5,12.5,0,0,1,259.12,760.58Z"/>
          <path class="a472110a-fd09-4fe3-b8f9-c387215f19e5" d="M101.19,863a12.5,12.5,0,1,1-8.46,15.52A12.5,12.5,0,0,1,101.19,863Z"/>
          <path d="M180.09,1156.25a7.81,7.81,0,1,1-5.28,9.7A7.82,7.82,0,0,1,180.09,1156.25Z"/>
          <path d="M203.61,837.91a6.39,6.39,0,1,1-4.32,7.93A6.38,6.38,0,0,1,203.61,837.91Z"/>
          <path d="M288.92,455.72a6.39,6.39,0,1,1-4.32,7.93A6.4,6.4,0,0,1,288.92,455.72Z"/>
          <path d="M267.26,625.18a6.38,6.38,0,1,1-4.32,7.92A6.37,6.37,0,0,1,267.26,625.18Z"/>
          <path d="M-3.27,474.82a6.38,6.38,0,0,1,7.93,4.32,6.39,6.39,0,0,1-4.33,7.93,6.38,6.38,0,0,1-7.92-4.33A6.38,6.38,0,0,1-3.27,474.82Z"/>
          <path d="M367.34,638.85a7.81,7.81,0,1,1-5.29,9.71A7.81,7.81,0,0,1,367.34,638.85Z"/>
          <path d="M371.47,1010.18a7.82,7.82,0,1,1-5.29,9.7A7.82,7.82,0,0,1,371.47,1010.18Z"/>
          <path class="f72dac7f-b23b-403c-a82b-2bf8a883154e" d="M176.78,484.58a12.5,12.5,0,1,1-8.47,15.52A12.5,12.5,0,0,1,176.78,484.58Z"/>
          <path class="f72dac7f-b23b-403c-a82b-2bf8a883154e" d="M-5,716.52A12.5,12.5,0,0,1,10.5,725,12.5,12.5,0,0,1,2,740.5,12.5,12.5,0,0,1-13.49,732,12.51,12.51,0,0,1-5,716.52Z"/>
        </g>
        <text class="b91c8b58-5547-4fb6-8314-fc5566156702" transform="translate(27.99 561.19)">フリーランス・コンサルタントの方々に<tspan x="0" y="28">プロジェクト案件をご紹介</tspan><tspan class="efb6ba7b-2cfa-4542-b530-5a7c4e0eda71" x="211.2" y="28">。</tspan><tspan x="0" y="56">アサイン後のフォローアップなど、ご登</tspan><tspan x="0" y="84">録者を支えるフォローが充実しているた</tspan><tspan x="0" y="112">め、継続的にご活用頂いております</tspan><tspan class="ff24884f-28b2-4729-9ebf-4dda5a1a114d" x="281.6" y="112">。</tspan><tspan x="0" y="140">独自の人脈だけではつながることが難し</tspan><tspan x="0" y="168">い案件や、ステップアップができる案件</tspan><tspan x="0" y="196">もご紹介することが可能です</tspan><tspan class="ff24884f-28b2-4729-9ebf-4dda5a1a114d" x="228.8" y="196">。</tspan></text>
        <text class="b91c8b58-5547-4fb6-8314-fc5566156702" transform="translate(35.99 1191.19)">ビジネスに役立つ情報から、IT・A<tspan class="b624284c-5327-46fb-9842-bc9e36c505a7" x="277.57" y="0">I</tspan><tspan x="287.15" y="0">の活</tspan><tspan x="0" y="28">用方法まで、セミナーを開催しておりま</tspan><tspan x="0" y="56">すので是非ご参加ください</tspan><tspan class="efb6ba7b-2cfa-4542-b530-5a7c4e0eda71" x="211.2" y="56">。</tspan><tspan x="0" y="84">サイバースミスでは、プロフェッショナ</tspan><tspan x="0" y="112">ル同士が意見交換をすることができる学</tspan><tspan x="0" y="140">びの場の開催にも取り組んでいますので</tspan><tspan class="ff24884f-28b2-4729-9ebf-4dda5a1a114d" x="316.8" y="140">、</tspan><tspan x="0" y="168">新しい技術や興味のある分野など、視野</tspan><tspan x="0" y="196">を広げるお手伝いもしています</tspan><tspan class="ff24884f-28b2-4729-9ebf-4dda5a1a114d" x="246.4" y="196">。</tspan></text>
        <text class="ba131054-94e3-4bf3-bcf7-5d76bade886b" transform="translate(26.94 61.32)">WORK</text>
        <text class="ac31d36e-ca8d-419c-b7cb-23e22432e3ae" transform="translate(27.94 138.32)">プロフェッショナル<tspan x="0" y="45.5">同士がつながる</tspan></text>
        <g><a href="../matter_list_sp/">
          <text class="a4994349-7b19-434e-be19-b033bbb12065" transform="translate(72.8 798.64)">案件情報一覧</text>
          <line class="a6fb728e-886b-4199-aa38-1911aed5cc30" x1="71.99" y1="806.11" x2="177.99" y2="806.11"/>
          <circle cx="44.52" cy="793.83" r="13.51"/>
          <g>
            <path class="f1197513-0e57-47da-a99d-f29b45d8386e" d="M45.78,794.05s0,0,0,0v0a.14.14,0,0,0,0-.06h0a.43.43,0,0,0,0-.16h0a.14.14,0,0,0,0-.06h0a.08.08,0,0,0,0,0s0,0-.05-.06l-5.42-5.42a.39.39,0,0,0-.55,0l-1,1a.36.36,0,0,0-.12.27.36.36,0,0,0,.12.28l4.11,4.11-4.11,4.11a.36.36,0,0,0-.12.28.36.36,0,0,0,.12.27l1,1a.39.39,0,0,0,.28.12.39.39,0,0,0,.27-.12l5.42-5.41Z"/>
            <path class="f1197513-0e57-47da-a99d-f29b45d8386e" d="M51.78,794v0a.14.14,0,0,0,0-.06h0a.43.43,0,0,0,0-.16h0a.14.14,0,0,0,0-.06h0l0,0s0,0,0-.06l-5.42-5.42a.39.39,0,0,0-.55,0l-1,1a.39.39,0,0,0-.11.27.39.39,0,0,0,.11.28l4.11,4.11-4.11,4.11a.39.39,0,0,0-.11.28.39.39,0,0,0,.11.27l1,1a.39.39,0,0,0,.28.12.36.36,0,0,0,.27-.12l5.42-5.41,0-.06Z"/>
          </g>
        </a></g>
        <g><a href="../for_clients_sp/">
          <text class="a4994349-7b19-434e-be19-b033bbb12065" transform="translate(88.8 1428.64)">エンジニアを探している企業様へ</text>
          <line class="a6fb728e-886b-4199-aa38-1911aed5cc30" x1="87.99" y1="1436.11" x2="355.99" y2="1436.11"/>
          <circle cx="60.52" cy="1423.83" r="13.51"/>
          <g>
            <path class="f1197513-0e57-47da-a99d-f29b45d8386e" d="M61.78,1424.05s0,0,0,0v0a.14.14,0,0,0,0-.06h0a.43.43,0,0,0,0-.16h0a.14.14,0,0,0,0-.06h0a.08.08,0,0,0,0-.05s0,0-.05-.06l-5.42-5.42a.39.39,0,0,0-.55,0l-1,1a.36.36,0,0,0-.12.27.36.36,0,0,0,.12.28l4.11,4.11-4.11,4.11a.36.36,0,0,0-.12.28.36.36,0,0,0,.12.27l1,1a.39.39,0,0,0,.28.12.39.39,0,0,0,.27-.12l5.42-5.41Z"/>
            <path class="f1197513-0e57-47da-a99d-f29b45d8386e" d="M67.78,1424v0a.14.14,0,0,0,0-.06h0a.43.43,0,0,0,0-.16h0a.14.14,0,0,0,0-.06h0l0-.05s0,0,0-.06l-5.42-5.42a.39.39,0,0,0-.55,0l-1,1a.39.39,0,0,0-.11.27.39.39,0,0,0,.11.28l4.11,4.11-4.11,4.11a.39.39,0,0,0-.11.28.39.39,0,0,0,.11.27l1,1a.39.39,0,0,0,.28.12.36.36,0,0,0,.27-.12l5.42-5.41,0-.06Z"/>
          </g>
        </a></g>
        <g><a href="../for_worker_sp/">
          <text class="a4994349-7b19-434e-be19-b033bbb12065" transform="translate(88.8 1473.64)">お仕事を探している方へ</text>
          <line class="a6fb728e-886b-4199-aa38-1911aed5cc30" x1="87.99" y1="1481.11" x2="284.49" y2="1481.11"/>
          <circle cx="60.52" cy="1468.83" r="13.51"/>
          <g>
            <path class="f1197513-0e57-47da-a99d-f29b45d8386e" d="M61.78,1469.05s0,0,0,0v0a.14.14,0,0,0,0-.06h0a.43.43,0,0,0,0-.16h0a.14.14,0,0,0,0-.06h0a.08.08,0,0,0,0-.05s0,0-.05-.06l-5.42-5.42a.39.39,0,0,0-.55,0l-1,1a.36.36,0,0,0-.12.27.36.36,0,0,0,.12.28l4.11,4.11-4.11,4.11a.36.36,0,0,0-.12.28.36.36,0,0,0,.12.27l1,1a.39.39,0,0,0,.28.12.39.39,0,0,0,.27-.12l5.42-5.41Z"/>
            <path class="f1197513-0e57-47da-a99d-f29b45d8386e" d="M67.78,1469v0a.14.14,0,0,0,0-.06h0a.43.43,0,0,0,0-.16h0a.14.14,0,0,0,0-.06h0l0-.05s0,0,0-.06l-5.42-5.42a.39.39,0,0,0-.55,0l-1,1a.39.39,0,0,0-.11.27.39.39,0,0,0,.11.28l4.11,4.11-4.11,4.11a.39.39,0,0,0-.11.28.39.39,0,0,0,.11.27l1,1a.39.39,0,0,0,.28.12.36.36,0,0,0,.27-.12l5.42-5.41,0-.06Z"/>
          </g>
        </a></g>
        
        <rect class="bc4267ef-c781-4c82-b39d-761d107383ae" x="-15" y="1530.57" width="397" height="829.43"/>
      </g>
    </g>
  </svg>
  <div class="horizontal-list" style="position: absolute; width:100vw; margin-top: 62vw;" id="hoge1">
    <div style="display: inline-block; box-shadow: 0 0 10px 0; margin-top: 5px; margin-left: 8%; height: 66vw; width: 66vw;"><object type="image/svg+xml" data="https://cybersmith-template-img.s3.ap-northeast-1.amazonaws.com/VD_toppage_matter.svg" width="100%"></object></div>
    <div style="display: inline-block; box-shadow: 0 0 10px 0; margin-top: 5px; margin-left: 8%; height: 66vw; width: 66vw;"><object type="image/svg+xml" data="https://cybersmith-template-img.s3.ap-northeast-1.amazonaws.com/VD_toppage_matter.svg" width="100%"></object></div>
    <div style="display: inline-block; box-shadow: 0 0 10px 0; margin-top: 5px; margin-left: 8%; margin-right: 8%; height: 66vw; width: 66vw;"><object type="image/svg+xml" data="https://cybersmith-template-img.s3.ap-northeast-1.amazonaws.com/VD_toppage_matter.svg" width="100%"></object></div>
    <div style="padding-left: 10%;"></div>
  </div>
  <div class="horizontal-list" style="position: absolute; width:100vw; margin-top: 228vw;" id="hoge2">
    <div style="display: inline-block; box-shadow: 0 0 10px 0; margin-top: 5px; margin-left: 8%; height: 66vw; width: 66vw;"><object type="image/svg+xml" data="https://cybersmith-template-img.s3.ap-northeast-1.amazonaws.com/VD_toppage_seminer.svg" width="100%"></object></div>
    <div style="display: inline-block; box-shadow: 0 0 10px 0; margin-top: 5px; margin-left: 8%; height: 66vw; width: 66vw;"><object type="image/svg+xml" data="https://cybersmith-template-img.s3.ap-northeast-1.amazonaws.com/VD_toppage_seminer.svg" width="100%"></object></div>
    <div style="display: inline-block; box-shadow: 0 0 10px 0; margin-top: 5px; margin-left: 8%; margin-right: 8%; height: 66vw; width: 66vw;"><object type="image/svg+xml" data="https://cybersmith-template-img.s3.ap-northeast-1.amazonaws.com/VD_toppage_seminer.svg" width="100%"></object></div>
    <div style="padding-left: 10%;"></div>
  </div>
</div>