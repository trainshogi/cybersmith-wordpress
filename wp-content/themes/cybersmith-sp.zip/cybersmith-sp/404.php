<?php get_header(); ?>
記事が見つかりません。
<?php get_footer(); ?>