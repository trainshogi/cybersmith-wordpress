  <footer>
    <svg id="e21421cd-dafa-41d9-b785-54c003341b2c" data-name="レイヤー 1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 374 871">
      <defs>
        <style>
          .e47f9aac-4a3b-425e-a647-103d8c4da613 {
            fill: none;
          }

          .b68dc912-08d1-4249-8526-7a55e5188f7d {
            fill: #002e4e;
          }

          .a5123f33-8205-431f-b08d-d7d190cbf406 {
            fill: #df7163;
          }

          .ab4c8d90-07d0-48ce-bdf1-ebd7683de70d {
            opacity: 0.2;
          }

          .b069c161-1fff-4566-8a26-07d6bacac7e9 {
            font-size: 36px;
            font-family: FutoGoB101Pr6N-Bold, FutoGoB101Pr6N Bold-83pv-RKSJ-H;
            font-weight: 700;
            letter-spacing: 0.2em;
          }

          .adbd92b0-20fa-42fe-be7a-c2ae504bb931, .afd693b8-ae96-4d06-8ebf-5cfdcfb9200e, .b069c161-1fff-4566-8a26-07d6bacac7e9 {
            fill: #fff;
          }

          .afd693b8-ae96-4d06-8ebf-5cfdcfb9200e {
            font-size: 14px;
            font-family: HiraKakuProN-W3-83pv-RKSJ-H, Hiragino Kaku Gothic ProN;
            letter-spacing: 0.1em;
          }

          .adbd92b0-20fa-42fe-be7a-c2ae504bb931 {
            font-size: 10px;
            font-family: Verdana;
            letter-spacing: 0.2em;
          }

          .a8aca1e5-4334-48f5-8133-ba16f8742de4 {
            font-size: 26px;
            font-family: KozGoPr6N-Bold-83pv-RKSJ-H, Kozuka Gothic Pr6N;
          }

          .ab675e01-e4ba-4a70-bd67-c23c29cf2a04 {
            clip-path: url(#b9655342-8eb1-482c-9367-ca9581be1f0d);
          }

          .b1636575-22d1-4a73-affa-b1d330203faf {
            fill: #83ccd2;
            opacity: 0.79;
          }

          .b2643fe2-56b4-40ce-8a95-3ab9197b5c7e, .f08c8953-3000-4181-a540-434569a2b540 {
            fill: #3f3f3f;
          }

          .b2643fe2-56b4-40ce-8a95-3ab9197b5c7e {
            font-size: 21px;
            font-family: HiraginoSans-W6-83pv-RKSJ-H, Hiragino Sans;
          }

          .ac5aec5b-a6e5-4b2a-83a8-9245e9c20a36 {
            clip-path: url(#bc86c6b2-6a47-473c-9ece-fa2adf6fd765);
          }
        </style>
        <clipPath id="b9655342-8eb1-482c-9367-ca9581be1f0d">
          <rect class="e47f9aac-4a3b-425e-a647-103d8c4da613" x="37.73" y="349.05" width="304.99" height="152.49"/>
        </clipPath>
        <clipPath id="bc86c6b2-6a47-473c-9ece-fa2adf6fd765">
          <rect class="e47f9aac-4a3b-425e-a647-103d8c4da613" x="39.01" y="549.99" width="304.99" height="152.49"/>
        </clipPath>
      </defs>
      <rect class="a5123f33-8205-431f-b08d-d7d190cbf406" x="-4.27" width="384.27" height="875.05"/>
      <rect class="b68dc912-08d1-4249-8526-7a55e5188f7d" x="-4.27" width="384.27" height="740"/>
      <text class="b069c161-1fff-4566-8a26-07d6bacac7e9" transform="translate(37.78 208.53)">幸福が循環する<tspan x="43.2" y="63">社会を創る</tspan></text>
      <text class="afd693b8-ae96-4d06-8ebf-5cfdcfb9200e" transform="translate(52.14 783.15)"><a href="/company_sp/">運営会社</a> / <a href="/tos_sp/">ご利用規約</a> / <a href="/qa_sp/">よくある質問</a></text>
      <text class="adbd92b0-20fa-42fe-be7a-c2ae504bb931" transform="translate(37.54 817.97)">Copyright © Cybersmith All rights reserved.</text>
      <image width="219.86" transform="translate(73.31 5.2)" xlink:href="http://3.112.250.183/wp-content/uploads/2021/12/logo.svg"/>
      <g class="ab4c8d90-07d0-48ce-bdf1-ebd7683de70d">
        <path d="M342.71,349.05V501.54h-305V349.05h305m7.63-7.63H30.1V509.17H350.34V341.42Z"/>
      </g>
      <g class="ab675e01-e4ba-4a70-bd67-c23c29cf2a04">
        <image width="1980" height="1320" transform="translate(-27.47 290.34) scale(0.2)" xlink:href="http://3.112.250.183/wp-content/uploads/2021/11/pixta_66330729_XL.jpg"/>
      </g>
      <g class="ab4c8d90-07d0-48ce-bdf1-ebd7683de70d">
        <path d="M344,550V702.48H39V550H344m7.62-7.62H31.39V710.11H351.62V542.37Z"/>
      </g>
      <g class="ac5aec5b-a6e5-4b2a-83a8-9245e9c20a36">
        <image width="1980" height="1320" transform="translate(29.86 527.37) scale(0.16)" xlink:href="http://3.112.250.183/wp-content/uploads/2021/11/pixta_63366991_XL.jpg"/>
      </g>
      <g><a href="../for_clients_sp/">
        <rect class="b1636575-22d1-4a73-affa-b1d330203faf" x="37.73" y="349.05" width="304.99" height="152.49"/>
        <g>
          <path class="f08c8953-3000-4181-a540-434569a2b540" d="M87.3,403.64a3.18,3.18,0,1,0,3.18,3.18A3.18,3.18,0,0,0,87.3,403.64Z"/>
          <circle class="f08c8953-3000-4181-a540-434569a2b540" cx="96.32" cy="415.84" r="3.18"/>
          <path class="f08c8953-3000-4181-a540-434569a2b540" d="M87.3,439.7a3.18,3.18,0,1,0,3.18,3.18A3.18,3.18,0,0,0,87.3,439.7Z"/>
          <circle class="f08c8953-3000-4181-a540-434569a2b540" cx="96.32" cy="433.87" r="3.18"/>
          <path class="f08c8953-3000-4181-a540-434569a2b540" d="M105.33,421.67a3.18,3.18,0,1,0,3.18,3.18A3.18,3.18,0,0,0,105.33,421.67Z"/>
        </g>
        <text class="b2643fe2-56b4-40ce-8a95-3ab9197b5c7e" transform="translate(151.32 433.92)">企業様へ</text>
      </a></g>
      <g><a href="../for_worker_sp/">
        <rect class="b1636575-22d1-4a73-affa-b1d330203faf" x="39.01" y="549.99" width="304.99" height="152.49"/>
        <g>
          <path class="f08c8953-3000-4181-a540-434569a2b540" d="M88.3,615.64a3.18,3.18,0,1,0,3.18,3.18A3.18,3.18,0,0,0,88.3,615.64Z"/>
          <circle class="f08c8953-3000-4181-a540-434569a2b540" cx="97.32" cy="627.84" r="3.18"/>
          <path class="f08c8953-3000-4181-a540-434569a2b540" d="M88.3,651.7a3.18,3.18,0,1,0,3.18,3.18A3.18,3.18,0,0,0,88.3,651.7Z"/>
          <circle class="f08c8953-3000-4181-a540-434569a2b540" cx="97.32" cy="645.87" r="3.18"/>
          <path class="f08c8953-3000-4181-a540-434569a2b540" d="M106.33,633.67a3.18,3.18,0,1,0,3.18,3.18A3.18,3.18,0,0,0,106.33,633.67Z"/>
        </g>
        <text class="b2643fe2-56b4-40ce-8a95-3ab9197b5c7e" transform="translate(144.32 621.92)">お仕事を<tspan x="0" y="36.75">探している方へ</tspan></text>
      </a></g>
    </svg>
  </footer>
  <?php wp_footer(); ?>
 </body>
</html>